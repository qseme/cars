package com.example.carlauncher

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.*
import android.location.Location
import android.location.LocationListener
import android.os.Looper
import android.os.Bundle
import android.location.LocationManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Fix(val lat: Double, val lon: Double, val speedKmh: Float, val bearing: Float, val alt: Double, val accuracyM: Float = 999f, val timeMs: Long = System.currentTimeMillis())
enum class LocationQuality { SEARCHING, GOOD, WEAK, LOST }
object LocationState { val quality = MutableStateFlow(LocationQuality.SEARCHING); val message = MutableStateFlow("جارٍ تحديد الموقع") }

object NavState { val text = MutableStateFlow("") }

object Loc {
    val fix = MutableStateFlow<Fix?>(null)
    private var lm: LocationManager? = null
    private var listener: LocationListener? = null
    private var lastAccepted: Location? = null
    @SuppressLint("MissingPermission")
    fun start(c: Context) {
        if (listener != null) return
        val manager = c.getSystemService(LocationManager::class.java) ?: return
        lm = manager
        if (!isLocationEnabled(manager)) { LocationState.quality.value = LocationQuality.LOST; LocationState.message.value = "خدمات الموقع متوقفة"; return }
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) { accept(location) }
            override fun onProviderEnabled(provider: String) { LocationState.message.value = "جارٍ تحديد الموقع…" }
            override fun onProviderDisabled(provider: String) { if (!isLocationEnabled(manager)) { LocationState.quality.value = LocationQuality.LOST; LocationState.message.value = "خدمات الموقع متوقفة" } }
            @Deprecated("Deprecated") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        listener = l
        runCatching {
            val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            last?.let { accept(it, true) }
        }
        var requested = false
        runCatching { if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) { manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper()); requested = true } }
        runCatching { if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) { manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, l, Looper.getMainLooper()); requested = true } }
        if (requested) { LocationState.quality.value = LocationQuality.SEARCHING; LocationState.message.value = "جارٍ تحديد موقع دقيق…" } else { LocationState.quality.value = LocationQuality.LOST; LocationState.message.value = "تعذر بدء تحديد الموقع" }
    }
    private fun isLocationEnabled(manager: LocationManager): Boolean =
        runCatching { manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)
    private fun accept(l: Location, stale: Boolean = false) {
        val age = System.currentTimeMillis() - l.time
        val acc = if (l.hasAccuracy()) l.accuracy else 999f
        if (!stale && (age > 20000 || acc > 150f)) { LocationState.quality.value = LocationQuality.WEAK; LocationState.message.value = "إشارة الموقع ضعيفة"; return }
        val prev = lastAccepted
        if (!stale && prev != null && l.time > prev.time) {
            val dt = ((l.time-prev.time).coerceAtLeast(1000L))/1000f
            val jump = prev.distanceTo(l)
            val estimated = if (l.hasSpeed()) l.speed else jump/dt
            if (jump > 250f && estimated > 55f) { LocationState.message.value = "تم تجاهل قراءة موقع غير مستقرة"; return }
        }
        if (!stale && (prev == null || l.time >= prev.time)) lastAccepted = l
        fix.value = Fix(l.latitude, l.longitude, if (l.hasSpeed()) l.speed*3.6f else 0f, if (l.hasBearing()) l.bearing else 0f, if (l.hasAltitude()) l.altitude else Double.NaN, acc, l.time)
        if (stale || age > 5000) { LocationState.quality.value = LocationQuality.WEAK; LocationState.message.value = "آخر موقع معروف — بانتظار تحديث مباشر" }
        else if (acc <= 30f) { LocationState.quality.value = LocationQuality.GOOD; LocationState.message.value = "موقع دقيق ±${acc.toInt()} م" }
        else { LocationState.quality.value = LocationQuality.WEAK; LocationState.message.value = "دقة الموقع ±${acc.toInt()} م" }
    }
    fun stop() { runCatching { listener?.let { lm?.removeUpdates(it) } }; listener = null; lm = null }
}

object Compass {
    val az = MutableStateFlow(0f)
    private var sm: SensorManager? = null
    private var registered = false
    private val callback = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val r = FloatArray(9); val o = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(r, e.values); SensorManager.getOrientation(r, o)
            val v = ((Math.toDegrees(o[0].toDouble()) + 360) % 360).toFloat()
            val old = Math.toRadians(az.value.toDouble()); val n = Math.toRadians(v.toDouble())
            val x = .8 * kotlin.math.cos(old) + .2 * kotlin.math.cos(n); val y = .8 * kotlin.math.sin(old) + .2 * kotlin.math.sin(n)
            az.value = ((Math.toDegrees(kotlin.math.atan2(y, x)) + 360) % 360).toFloat()
        }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }
    fun start(c: Context) {
        if (registered) return
        val manager = c.getSystemService(SensorManager::class.java) ?: return
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: return
        sm = manager; registered = manager.registerListener(callback, sensor, SensorManager.SENSOR_DELAY_GAME)
    }
    fun stop() { if (registered) sm?.unregisterListener(callback); registered = false }
}

object Data {
    val limit = MutableStateFlow<Int?>(null)
    val weather = MutableStateFlow<Pair<Int, Int>?>(null) // حرارة، رمز
    private var job: Job? = null
    private var lastLimitAt = 0L
    private var lastWeatherAt = 0L
    private var lastLimitFix: Fix? = null

    private fun segmentDistanceMeters(pLat: Double, pLon: Double, aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val scaleX = 111320.0 * kotlin.math.cos(Math.toRadians(pLat))
        val scaleY = 110540.0
        val ax = (aLon-pLon)*scaleX; val ay = (aLat-pLat)*scaleY
        val bx = (bLon-pLon)*scaleX; val by = (bLat-pLat)*scaleY
        val dx = bx-ax; val dy = by-ay
        val denom = dx*dx+dy*dy
        val t = if (denom == 0.0) 0.0 else ((-ax*dx-ay*dy)/denom).coerceIn(0.0,1.0)
        return kotlin.math.hypot(ax+t*dx, ay+t*dy)
    }
    private fun distance(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Float {
        val a = Location("a").apply { latitude = aLat; longitude = aLon }
        val b = Location("b").apply { latitude = bLat; longitude = bLon }
        return a.distanceTo(b)
    }
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "CarLauncher/0.3 (personal)")
        c.connectTimeout = 15000; c.readTimeout = 25000
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    fun start(scope: CoroutineScope) {
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.IO) {
            Loc.fix.filterNotNull().collect { f ->
                val now = System.currentTimeMillis()
                if (now - lastLimitAt > 30000 || lastLimitFix?.let { distance(it.lat, it.lon, f.lat, f.lon) > 100 } != false) {
                    lastLimitAt = now; lastLimitFix = f
                    runCatching {
                        val q = "[out:json];way(around:18,${f.lat},${f.lon})[highway][maxspeed];out geom tags;"
                        val a = JSONObject(get("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8"))).getJSONArray("elements")
                        val carLoc = Location("car").apply { latitude = f.lat; longitude = f.lon }
                        val candidates = (0 until a.length()).mapNotNull { idx ->
                            val el = a.getJSONObject(idx); val tags = el.optJSONObject("tags") ?: return@mapNotNull null
                            var speed = Regex("\\d+").find(tags.optString("maxspeed"))?.value?.toIntOrNull() ?: return@mapNotNull null
                            if (tags.optString("maxspeed").contains("mph", true)) speed = (speed * 1.609).toInt()
                            if (speed !in 10..140) return@mapNotNull null
                            val geom = el.optJSONArray("geometry") ?: return@mapNotNull null
                            val points = (0 until geom.length()).map { j -> geom.getJSONObject(j) }
                            val nearest = if (points.size < 2) points.firstOrNull()?.let { distance(f.lat,f.lon,it.optDouble("lat"),it.optDouble("lon")).toDouble() } ?: return@mapNotNull null
                                else (0 until points.lastIndex).minOf { j -> segmentDistanceMeters(f.lat,f.lon,points[j].optDouble("lat"),points[j].optDouble("lon"),points[j+1].optDouble("lat"),points[j+1].optDouble("lon")) }
                            if (nearest > 18.0) return@mapNotNull null
                            val roadType = tags.optString("highway")
                            if (roadType in setOf("service", "footway", "path", "cycleway", "steps", "track")) return@mapNotNull null
                            speed to nearest
                        }
                        limit.value = candidates.minByOrNull { it.second }?.first
                    }.onFailure { limit.value = null }
                }
                if (now - lastWeatherAt > 900000) {
                    lastWeatherAt = now
                    runCatching {
                        val c = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${f.lat}&longitude=${f.lon}&current=temperature_2m,weather_code")).getJSONObject("current")
                        weather.value = Pair(Math.round(c.getDouble("temperature_2m")).toInt(), c.getInt("weather_code"))
                    }
                }
                delay(1500)
            }
        }
    }
    fun stop() { job?.cancel(); job = null }
}
