package com.example.carlauncher

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        val store = SettingsStore(applicationContext)
        val locationPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) Loc.start(applicationContext)
            else { LocationState.quality.value = LocationQuality.LOST; LocationState.message.value = "يرجى منح صلاحية الموقع من إعدادات التطبيق" }
        }
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) Loc.start(applicationContext)
        else locationPermissions.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        setContent {
            val prefs by store.flow.collectAsState(initial = Prefs())
            val accent = Color(prefs.accent)
            val scheme = if (prefs.dark)
                darkColorScheme(primary = accent, background = Color(0xFF0B0B0D), surface = Color(0xFF17171A))
            else lightColorScheme(primary = accent)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = scheme) {
                    var showSettings by remember { mutableStateOf(false) }
                    if (showSettings) SettingsScreen(prefs, store) { showSettings = false }
                    else HomeScreen(prefs, store) { showSettings = true }
                }
            }
        }
    }
    override fun onResume() {
        super.onResume()
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) Loc.start(applicationContext)
        Compass.start(applicationContext); Data.start(lifecycleScope)
    }
    override fun onPause() {
        Loc.stop(); Compass.stop(); Data.stop()
        super.onPause()
    }

}
