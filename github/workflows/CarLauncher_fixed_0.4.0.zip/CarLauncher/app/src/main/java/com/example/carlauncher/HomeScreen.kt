package com.example.carlauncher

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.batoulapps.adhan.*
import com.batoulapps.adhan.data.DateComponents
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

const val GOOGLE_MAPS = "com.google.android.apps.maps"
const val HUDHUD = "sa.hudhud.maps"
const val WAZE = "com.waze"

fun openMaps(c: Context, choice: String) {
    if (choice == "offline") { Toast.makeText(c, "الخريطة الداخلية تعمل في الشاشة الرئيسية", Toast.LENGTH_SHORT).show(); return }
    val pkg = when (choice) { "waze" -> WAZE; "hudhud" -> HUDHUD; else -> GOOGLE_MAPS }
    val launch = c.packageManager.getLaunchIntentForPackage(pkg)
    if (launch != null) { launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(launch) }
    else {
        val url = when (choice) { "waze" -> "https://www.waze.com/ul"; "hudhud" -> "https://play.google.com/store/apps/details?id=$HUDHUD"; else -> "https://maps.google.com" }
        runCatching { c.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(c, "تعذر فتح تطبيق الخرائط", Toast.LENGTH_SHORT).show() }
    }
}

@Composable
fun HomeScreen(prefs: Prefs, store: SettingsStore, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    BoxWithConstraints(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    val compact = maxHeight < 450.dp
    Row(Modifier.fillMaxSize().padding(if (compact) 8.dp else 12.dp),
        horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 12.dp)) {
        Column(Modifier.width(56.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton({ }) { Icon(Icons.Default.Home, null) }
            IconButton({ openMaps(ctx, prefs.maps) }) { Icon(Icons.Default.Map, null) }
            IconButton(onSettings) { Icon(Icons.Default.Settings, null) }
        }
        MapCard(prefs, Modifier.weight(1.5f).fillMaxHeight())
        MediaCard(Modifier.weight(1f).fillMaxHeight())
        TodayCard(compact, Modifier.weight(1.1f).fillMaxHeight())
    }
    }
}

@Composable
fun AppCard(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) =
    Card(modifier, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxSize().padding(14.dp), content = content)
    }

private val MAP_HTML = """
<html><head><meta name=viewport content="width=device-width,initial-scale=1">
<link rel=stylesheet href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body,#m{margin:0;height:100%;background:#111}</style></head><body><div id=m></div><script>
var map=L.map('m',{zoomControl:false,attributionControl:true}).setView([0,0],2),tl,offline=false,darkMode=true,forceRefresh=false;
var me=L.circleMarker([0,0],{radius:9,color:'#fff',weight:3,fillColor:'#E53935',fillOpacity:1}).addTo(map);
const DB='carlauncher_tiles_v1';let db;
function openDb(){return new Promise((resolve)=>{let r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('tiles');r.onsuccess=()=>{db=r.result;resolve(db)};r.onerror=()=>resolve(null)})}
async function tileGet(k){if(!db)return null;return new Promise(res=>{let t=db.transaction('tiles','readonly').objectStore('tiles').get(k);t.onsuccess=()=>res(t.result||null);t.onerror=()=>res(null)})}
async function tilePut(k,v){if(!db||offline)return;try{let t=db.transaction('tiles','readwrite');t.objectStore('tiles').put(v,k)}catch(e){}}
function setTheme(d){darkMode=d;if(tl)map.removeLayer(tl);let url=d?'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png':'https://tile.openstreetmap.org/{z}/{x}/{y}.png';tl=L.tileLayer(url,{maxZoom:19,attribution:'© OpenStreetMap contributors'});tl.createTile=function(coords,done){let img=document.createElement('img');img.alt='';img.setAttribute('role','presentation');let key=url.replace('{s}','a').replace('{z}',coords.z).replace('{x}',coords.x).replace('{y}',coords.y);tileGet(key).then(blob=>{if(blob&&!forceRefresh){img.src=URL.createObjectURL(blob);done(null,img);if(!offline)fetch(key).then(r=>r.ok?r.blob():null).then(b=>{if(b)tilePut(key,b)}).catch(()=>{});return}if(offline){img.src='';done(null,img);return}fetch(key).then(r=>r.ok?r.blob():Promise.reject()).then(blob=>{tilePut(key,blob);img.src=URL.createObjectURL(blob);done(null,img)}).catch(()=>done(null,img))});return img};tl.addTo(map)}
function setOffline(v){offline=v;setTheme(darkMode)}
function refreshTiles(){if(tl&&!offline){forceRefresh=true;tl.redraw();setTimeout(()=>forceRefresh=false,1200)}}
function setAccent(c){me.setStyle({fillColor:c})}
function pos(a,b){me.setLatLng([a,b]);if(!window.hasFix){map.setView([a,b],15,{animate:false});window.hasFix=true}else map.panTo([a,b],{animate:false})}
openDb().then(()=>setTheme(true));
</script></body></html>
"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MapCard(prefs: Prefs, modifier: Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fix by Loc.fix.collectAsState()
    val limit by Data.limit.collectAsState()
    val nav by NavState.text.collectAsState()
    var ready by remember { mutableStateOf(false) }
    val wv = remember {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            setBackgroundColor(0)
            webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView?, u: String?) { ready = true } }
            loadDataWithBaseURL("https://localhost", MAP_HTML, "text/html", "utf-8", null)
        }
    }
    val offlineMode = prefs.maps == "offline"
    LaunchedEffect(ready, prefs.dark, prefs.accent, prefs.maps) {
        if (ready) wv.evaluateJavascript("setTheme(${prefs.dark});setAccent('#%06X');setOffline($offlineMode)".format(prefs.accent and 0xFFFFFF), null)
    }
    LaunchedEffect(ready, fix) { fix?.let { if (ready) wv.evaluateJavascript("pos(${it.lat},${it.lon})", null) } }

    Card(modifier, shape = RoundedCornerShape(20.dp)) {
        Box(Modifier.fillMaxSize()) {
            AndroidView({ wv }, Modifier.fillMaxSize())
            limit?.let {
                Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(54.dp).clip(CircleShape).background(Color.White)
                    .border(5.dp, Color(0xFFD32F2F), CircleShape), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("$it", color = Color.Black, fontSize = 20.sp)
                        Text("تقريبي", color=Color.DarkGray, fontSize=7.sp)
                    }
                }
            }
            val gpsText by LocationState.message.collectAsState()
            Surface(Modifier.align(Alignment.TopStart).padding(8.dp), color=Color(0xCC000000), shape=RoundedCornerShape(8.dp)) {
                Text(gpsText, Modifier.padding(horizontal=8.dp, vertical=5.dp), color=Color.White, fontSize=10.sp, maxLines=1)
            }
            Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                if (nav.isNotEmpty()) Surface(shape = RoundedCornerShape(10.dp), color = Color(0xCC000000)) {
                    Text(nav, Modifier.padding(8.dp), color = Color.White, fontSize = 14.sp, maxLines = 2)
                }
                Spacer(Modifier.height(6.dp))
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                    Column(Modifier.size(64.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("${fix?.speedKmh?.toInt() ?: 0}", color = Color.White, fontSize = 24.sp)
                        Text("كم/س", color = Color.White, fontSize = 10.sp)
                    }
                }
            }
            Column(Modifier.align(Alignment.BottomEnd).padding(8.dp), horizontalAlignment=Alignment.End, verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    FilledIconButton({ openMaps(ctx, "google") }) { Icon(Icons.Default.Map, "Google Maps") }
                    FilledIconButton({ openMaps(ctx, "waze") }) { Icon(Icons.Default.Traffic, "Waze") }
                    FilledIconButton({ openMaps(ctx, "hudhud") }) { Icon(Icons.Default.Navigation, "هدهد") }
                }
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    FilledTonalButton(onClick={ if(ready) wv.evaluateJavascript("setOffline(true)",null) }) { Text("بدون إنترنت") }
                    FilledTonalButton(onClick={ if(ready) wv.evaluateJavascript("setOffline(false)",null) }) { Text("متصل") }
                    FilledTonalButton(onClick={ if(ready) wv.evaluateJavascript("refreshTiles()",null) }) { Text("تحديث") }
                }
            }
        }
    }
}

@Composable
fun MediaCard(modifier: Modifier) {
    val title by MediaState.title.collectAsState()
    val artist by MediaState.artist.collectAsState()
    val playing by MediaState.playing.collectAsState()
    val source by MediaState.source.collectAsState()
    AppCard(modifier) {
        Icon(Icons.Default.GraphicEq, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 18.sp, maxLines = 2)
        Text(artist, fontSize = 14.sp, color = Color.Gray, maxLines = 1)
        Text(if (source.isNotBlank()) "المصدر: ${source.substringAfterLast('.') }" else "بانتظار جلسة صوت مدعومة", fontSize=10.sp, color=Color.Gray, maxLines=1)
        Text("يتحكم في التطبيقات والراديو إذا وفر النظام جلسة وسائط. الراديو المدمج قد لا يكون متاحاً للنظام.", fontSize=9.sp, color=Color.Gray, maxLines=2)
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            IconButton({ MediaState.controller?.transportControls?.skipToPrevious() }) { Icon(Icons.Default.SkipPrevious, null) }
            IconButton({ val t = MediaState.controller?.transportControls; if (playing) t?.pause() else t?.play() }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            IconButton({ MediaState.controller?.transportControls?.skipToNext() }) { Icon(Icons.Default.SkipNext, null) }
        }
    }
}

private fun weatherText(c: Int) = when (c) {
    0 -> "صحو"; 1, 2, 3 -> "غائم جزئياً"; 45, 48 -> "ضباب"; in 51..67 -> "مطر"
    in 71..77 -> "ثلج"; in 80..82 -> "أمطار"; in 95..99 -> "عاصفة"; else -> ""
}
private val NAMES = mapOf(Prayer.FAJR to "الفجر", Prayer.SUNRISE to "الشروق", Prayer.DHUHR to "الظهر",
    Prayer.ASR to "العصر", Prayer.MAGHRIB to "المغرب", Prayer.ISHA to "العشاء")

@Composable
fun TodayCard(compact: Boolean, modifier: Modifier) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val fix by Loc.fix.collectAsState()
    val weather by Data.weather.collectAsState()
    val az by Compass.az.collectAsState()
    val ar = Locale("ar")
    val greg = java.text.SimpleDateFormat("EEEE d MMMM", ar).format(now)
    val hijri = try { DateTimeFormatter.ofPattern("d MMMM yyyy", ar).format(HijrahDate.now()) } catch (e: Exception) { "" }
    val co = Coordinates(fix?.lat ?: 0.0, fix?.lon ?: 0.0)
    val params = CalculationMethod.UMM_AL_QURA.parameters
    val pt = PrayerTimes(co, DateComponents.from(now), params)
    var next = pt.nextPrayer(); var at = pt.timeForPrayer(next)
    if (next == Prayer.NONE || at == null) {
        next = Prayer.FAJR
        at = PrayerTimes(co, DateComponents.from(Date(now.time + 86400000L)), params).fajr
    }
    val mins = ((at.time - now.time) / 60000).coerceAtLeast(0)
    val heading = if ((fix?.speedKmh ?: 0f) > 5f) fix!!.bearing else az
    val qibla = Qibla(co).direction.toFloat()

    AppCard(modifier) {
        if (compact) AnalogClock(Modifier.fillMaxWidth().height(76.dp)) else AnalogClock(Modifier.fillMaxWidth().weight(1f))
        Text(greg, fontSize = if (compact) 13.sp else 16.sp, maxLines = 1)
        if (!compact) Text(hijri, fontSize = 12.sp, color = Color.Gray)
        Spacer(Modifier.height(if (compact) 4.dp else 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile(Modifier.weight(1f), "الطقس", weather?.let { "${it.first}°  ${weatherText(it.second)}" } ?: "--")
            Tile(Modifier.weight(1f), "الصلاة", if (fix != null) "${NAMES[next]} بعد ${mins / 60}:${"%02d".format(mins % 60)}" else "بانتظار الموقع")
        }
        Spacer(Modifier.height(if (compact) 4.dp else 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile(Modifier.weight(1f), "القبلة", if (fix != null) "${qibla.toInt()}°" else "—") {
                if (fix != null) Icon(Icons.Default.Navigation, null, Modifier.size(22.dp).rotate(qibla - heading), tint = MaterialTheme.colorScheme.primary)
            }
            Tile(Modifier.weight(1f), "الارتفاع", if (fix?.alt?.isNaN() == false) "${fix!!.alt.toInt()} م" else "—")
        }
    }
}

@Composable
fun Tile(modifier: Modifier, label: String, value: String, extra: @Composable () -> Unit = {}) =
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(10.dp)) {
            Text(label, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(value, fontSize = 16.sp, maxLines = 1); extra()
            }
        }
    }

@Composable
fun AnalogClock(modifier: Modifier) {
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { now = Calendar.getInstance(); delay(1000) } }
    val tick = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val c = center; val r = size.minDimension / 2
        repeat(12) {
            val a = Math.toRadians(it * 30.0 - 90)
            val d = Offset(cos(a).toFloat(), sin(a).toFloat())
            drawLine(tick.copy(alpha = .5f), c + d * (r * .88f), c + d * r, 4f)
        }
        fun hand(deg: Double, len: Float, w: Float, col: Color) {
            val a = Math.toRadians(deg - 90)
            drawLine(col, c, c + Offset(cos(a).toFloat(), sin(a).toFloat()) * (r * len), w, StrokeCap.Round)
        }
        val h = now.get(Calendar.HOUR); val m = now.get(Calendar.MINUTE); val s = now.get(Calendar.SECOND)
        hand((h + m / 60.0) * 30, .5f, 8f, tick)
        hand((m + s / 60.0) * 6, .75f, 5f, tick)
        hand(s * 6.0, .85f, 3f, accent)
    }
}
