package com.example.carlauncher

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

data class Prefs(val accent: Long = 0xFFE53935, val dark: Boolean = true, val maps: String = "google")

private val Context.ds by preferencesDataStore("prefs")

class SettingsStore(private val c: Context) {
    private val A = longPreferencesKey("accent"); private val D = booleanPreferencesKey("dark")
    private val M = stringPreferencesKey("maps")
    val flow = c.ds.data.map { Prefs(it[A] ?: 0xFFE53935, it[D] ?: true, it[M] ?: "google") }
    suspend fun update(f: (Prefs) -> Prefs) {
        val n = f(flow.first())
        c.ds.edit { it[A] = n.accent; it[D] = n.dark; it[M] = n.maps }
    }
}
