package com.example.carlauncher

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val COLORS = listOf(0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFFFB300, 0xFF8E24AA, 0xFF00ACC1)

@Composable
fun SettingsScreen(prefs: Prefs, store: SettingsStore, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الإعدادات", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            Button(onBack) { Text("رجوع") }
        }
        Text("اللون الرئيسي")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            COLORS.forEach { c ->
                Box(Modifier.size(44.dp).clip(CircleShape).background(Color(c))
                    .border(if (prefs.accent == c) 3.dp else 0.dp, Color.White, CircleShape)
                    .clickable { scope.launch { store.update { it.copy(accent = c) } } })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الوضع الداكن", Modifier.weight(1f))
            Switch(prefs.dark, { v -> scope.launch { store.update { it.copy(dark = v) } } })
        }
        Text("تطبيق الخرائط")
        Text("اختيار تطبيق الملاحة الافتراضي")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(prefs.maps == "google", { scope.launch { store.update { it.copy(maps = "google") } } }, { Text("Google Maps") })
                FilterChip(prefs.maps == "waze", { scope.launch { store.update { it.copy(maps = "waze") } } }, { Text("Waze") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(prefs.maps == "hudhud", { scope.launch { store.update { it.copy(maps = "hudhud") } } }, { Text("هدهد") })
                FilterChip(prefs.maps == "offline", { scope.launch { store.update { it.copy(maps = "offline") } } }, { Text("الخريطة داخل التطبيق") })
            }
        }
        Text("الخريطة المحلية تحفظ البلاطات التي تم عرضها مسبقاً لاستخدامها عند انقطاع الإنترنت. تحديثها يتم بإعادة تحميل المنطقة أثناء الاتصال؛ لا تتوفر حالياً تنزيلات مناطق كاملة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
            Text("تفعيل التحكم بالوسائط والصوت من لوحة السيارة")
        }
    }
}
