package com.example.carlauncher

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

object MediaState {
    val title = MutableStateFlow("لا يوجد تشغيل")
    val artist = MutableStateFlow("")
    val playing = MutableStateFlow(false)
    val source = MutableStateFlow("")
    @Volatile var controller: MediaController? = null
}

/** يحتاج منح "الوصول إلى الإشعارات" من الإعدادات */
class MediaListener : NotificationListenerService() {
    private var current: MediaController? = null
    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
    }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener({ bind(it) }, cn)
        bind(msm.getActiveSessions(cn))
    }

    private fun bind(list: List<MediaController>?) {
        current?.unregisterCallback(cb)
        val sessions = list.orEmpty()
        current = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
            ?: sessions.firstOrNull()
        current?.registerCallback(cb)
        MediaState.controller = current
        MediaState.source.value = current?.packageName ?: ""
        push()
    }

    override fun onListenerDisconnected() { requestRebind(ComponentName(this, MediaListener::class.java)); MediaState.controller = null; MediaState.title.value = "لا يوجد تشغيل"; MediaState.artist.value = ""; MediaState.playing.value = false }
    private fun push() {
        val m = current?.metadata
        MediaState.title.value = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "لا يوجد تشغيل"
        MediaState.artist.value = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        MediaState.playing.value = current?.playbackState?.state == PlaybackState.STATE_PLAYING
        MediaState.source.value = current?.packageName ?: ""
    }

    private val navPkgs = setOf("com.google.android.apps.maps", "com.waze", "sa.hudhud.maps")
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in navPkgs) return
        val e = sbn.notification.extras
        NavState.text.value = listOfNotNull(e.getCharSequence("android.title"), e.getCharSequence("android.text")).joinToString(" • ")
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null && sbn.packageName in navPkgs) NavState.text.value = ""
    }
}
